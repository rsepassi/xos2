#include "wren.h"

WrenForeignMethodFn benchmarkBindMethod(const char* signature);
