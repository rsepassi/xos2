#include "wren.h"

int callRunTests(WrenVM* vm);
