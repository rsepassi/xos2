#include "wren.h"

WrenForeignMethodFn callCallsForeignBindMethod(const char* signature);
int callCallsForeignRunTests(WrenVM* vm);
