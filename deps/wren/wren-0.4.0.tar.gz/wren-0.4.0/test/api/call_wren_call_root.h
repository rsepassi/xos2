#include "wren.h"

int callWrenCallRootRunTests(WrenVM* vm);
