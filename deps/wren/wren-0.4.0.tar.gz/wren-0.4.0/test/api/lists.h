#include "wren.h"

WrenForeignMethodFn listsBindMethod(const char* signature);
