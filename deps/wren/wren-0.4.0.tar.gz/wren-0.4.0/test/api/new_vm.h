#include "wren.h"

WrenForeignMethodFn newVMBindMethod(const char* signature);
