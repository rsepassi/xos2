#include "wren.h"

int resetStackAfterCallAbortRunTests(WrenVM* vm);