#include "wren.h"

WrenForeignMethodFn userDataBindMethod(const char* signature);
