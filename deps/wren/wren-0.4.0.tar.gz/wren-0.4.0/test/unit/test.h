// Set this to 1 to output passing tests.
#define SHOW_PASSES 0

void pass();
void fail();

int showTestResults();
