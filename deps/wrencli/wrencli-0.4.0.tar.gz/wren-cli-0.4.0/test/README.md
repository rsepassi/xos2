This contains the automated validation suite for the CLI.

* `unit/` - tests various aspects of the CLI core APIs.

* `*/` - tests various modules and mechanics of the CLI, like module resolution.
