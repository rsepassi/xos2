#include "path_test.h"
#include "test.h"

int main()
{
  testPath();
  
  return showTestResults();
}
